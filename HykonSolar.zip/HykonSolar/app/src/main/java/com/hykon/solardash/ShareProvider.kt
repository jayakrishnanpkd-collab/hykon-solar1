package com.hykon.solardash

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

/** Serves the summary image from the cache folder so WhatsApp and other apps can read it. */
class ShareProvider : ContentProvider() {
    private fun fileFor(uri: Uri): File {
        val name = File(uri.lastPathSegment ?: throw FileNotFoundException()).name
        val f = File(File(context!!.cacheDir, "share"), name)
        if (!f.isFile) throw FileNotFoundException(name)
        return f
    }

    override fun onCreate() = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor =
        ParcelFileDescriptor.open(fileFor(uri), ParcelFileDescriptor.MODE_READ_ONLY)

    override fun getType(uri: Uri): String {
        val n = uri.lastPathSegment ?: ""
        return when {
            n.endsWith(".gif") -> "image/gif"
            n.endsWith(".gz") -> "application/gzip"
            n.endsWith(".json") -> "application/json"
            else -> "image/png"
        }
    }

    override fun query(uri: Uri, p: Array<String>?, s: String?, a: Array<String>?, o: String?): Cursor? {
        val f = try { fileFor(uri) } catch (e: FileNotFoundException) { return null }
        val c = MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE))
        c.addRow(arrayOf<Any>(f.name, f.length()))
        return c
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<String>?) = 0
}
