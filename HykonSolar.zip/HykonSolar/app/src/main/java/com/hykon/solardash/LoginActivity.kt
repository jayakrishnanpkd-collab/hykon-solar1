package com.hykon.solardash

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

/**
 * Opens the DessMonitor website. When the page makes its sign-in request, the company key and
 * server address are read from that request's address and returned to the dashboard.
 * The password is typed on the website and is never read by the app.
 */
class LoginActivity : Activity() {

    private var done = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url
                val key = u.getQueryParameter("company-key")
                if (!key.isNullOrEmpty() && !done) {
                    done = true
                    var base = (u.scheme ?: "https") + "://" + (u.host ?: "")
                    if (u.port > 0) base += ":" + u.port
                    val path = u.path ?: ""
                    val i = path.indexOf("/public")
                    if (i > 0) base += path.substring(0, i)
                    val usr = u.getQueryParameter("usr") ?: ""
                    val sign = u.getQueryParameter("sign") ?: ""
                    val salt = u.getQueryParameter("salt") ?: ""
                    val q = u.encodedQuery ?: ""
                    val ai = q.indexOf("action=")
                    val rest = if (ai >= 0) "&" + q.substring(ai) else ""
                    runOnUiThread {
                        setResult(
                            RESULT_OK,
                            Intent().putExtra("base", base).putExtra("key", key).putExtra("usr", usr)
                                .putExtra("rest", rest).putExtra("sign", sign).putExtra("salt", salt)
                        )
                        Toast.makeText(this@LoginActivity, "Company key found", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
                return null
            }
        }
        Toast.makeText(this, "Sign in on the DessMonitor page", Toast.LENGTH_LONG).show()
        web.loadUrl(intent.getStringExtra("url") ?: "https://www.dessmonitor.com/")
    }
}
