package com.hykon.solardash

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class HykonWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        private fun build(context: Context): RemoteViews {
            val p = context.getSharedPreferences("hykon_widget", Context.MODE_PRIVATE)
            val v = RemoteViews(context.packageName, R.layout.widget)
            v.setTextViewText(R.id.w_pv, p.getString("pv", "-- W"))
            v.setTextViewText(R.id.w_soc, p.getString("soc", "--%"))
            v.setTextViewText(R.id.w_line, p.getString("line", "Open the app to load"))
            val open = Intent(context, MainActivity::class.java)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(context, 0, open, flags))
            return v
        }

        fun refresh(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, HykonWidget::class.java))
            for (id in ids) mgr.updateAppWidget(id, build(context))
        }
    }
}
